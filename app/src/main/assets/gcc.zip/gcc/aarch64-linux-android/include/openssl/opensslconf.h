// Auto-generated - DO NOT EDIT!
#ifndef OPENSSL_SYS_TRUSTY
#if defined(__LP64__)
#include "opensslconf-64.h"
#else
#include "opensslconf-32.h"
#endif
#else
#include "opensslconf-trusty.h"
#endif
