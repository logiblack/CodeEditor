// Auto-generated - DO NOT EDIT!
#if defined(__LP64__)
#include "opensslconf-static-64.h"
#else
#include "opensslconf-static-32.h"
#endif
